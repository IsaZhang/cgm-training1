const employees = [
  {"name":"杨书珍","phone":"18066971565","city":"西安","department":"运营","active":true},
  {"name":"王成芬","phone":"15596813331","city":"西安","department":"运营","active":true},
  {"name":"陈倩","phone":"13667158931","city":"西安","department":"运营","active":true},
  {"name":"秦菲","phone":"13992399352","city":"西安","department":"运营","active":true},
  {"name":"权宁","phone":"13571900105","city":"西安","department":"运营","active":true},
  {"name":"杨庆","phone":"18710839968","city":"西安","department":"运营","active":true},
  {"name":"薛冰","phone":"13474247851","city":"西安","department":"运营","active":true},
  {"name":"李洋洋","phone":"13571888223","city":"西安","department":"运营","active":true},
  {"name":"闫冰","phone":"13087529655","city":"西安","department":"运营","active":true},
  {"name":"吴沛","phone":"17778915321","city":"西安","department":"运营","active":true},
  {"name":"王李宁","phone":"15929923549","city":"西安","department":"运营","active":true},
  {"name":"张小云","phone":"17782552106","city":"西安","department":"运营","active":true},
  {"name":"吴丹","phone":"13389132227","city":"西安","department":"运营","active":true},
  {"name":"胡洁","phone":"13399695539","city":"合肥","department":"运营","active":true},
  {"name":"王玉叶","phone":"15056238192","city":"合肥","department":"运营","active":true},
  {"name":"刘雪云","phone":"15256926334","city":"合肥","department":"运营","active":true},
  {"name":"杭静","phone":"18105692571","city":"合肥","department":"运营","active":true},
  {"name":"丁文雅","phone":"18119669545","city":"合肥","department":"运营","active":true},
  {"name":"张燕","phone":"15395164610","city":"合肥","department":"运营","active":true},
  {"name":"郭倩倩","phone":"15755192141","city":"合肥","department":"运营","active":true},
  {"name":"何美红","phone":"15083775627","city":"合肥","department":"运营","active":true},
  {"name":"刘琴","phone":"13865805824","city":"合肥","department":"运营","active":true},
  {"name":"何亚丽","phone":"13679434963","city":"兰州","department":"运营","active":true},
  {"name":"陈一颖","phone":"13919984527","city":"兰州","department":"运营","active":true},
  {"name":"张慧旋","phone":"19976721221","city":"兰州","department":"运营","active":true},
  {"name":"刘淑娟","phone":"15979050679","city":"兰州","department":"运营","active":true},
  {"name":"冯麒诺","phone":"15682855363","city":"兰州","department":"运营","active":true},
  {"name":"蔡越","phone":"18409495711","city":"兰州","department":"运营","active":true},
  {"name":"刘颖","phone":"13919088953","city":"兰州","department":"运营","active":true},
  {"name":"张云芳","phone":"19893111656","city":"兰州","department":"运营","active":true},
  {"name":"覃小芸","phone":"13399462401","city":"兰州","department":"运营","active":true},
  {"name":"吴晓莉","phone":"18119447913","city":"兰州","department":"运营","active":true},
  {"name":"李珍慧","phone":"18722435433","city":"兰州","department":"运营","active":true},
  {"name":"赵丽","phone":"15002675116","city":"兰州","department":"运营","active":true},
  {"name":"胡明雁","phone":"18215174059","city":"兰州","department":"运营","active":true},
  {"name":"颜顺","phone":"19857845676","city":"兰州","department":"运营","active":true},
  {"name":"杨桐","phone":"15379042939","city":"兰州","department":"运营","active":true},
  {"name":"赵祝","phone":"18152107328","city":"兰州","department":"运营","active":true},
  {"name":"谈慧敏","phone":"18394491014","city":"兰州","department":"运营","active":true},
  {"name":"张丽娟","phone":"15117059086","city":"兰州","department":"运营","active":true},
  {"name":"李青青","phone":"15038561990","city":"北京","department":"运营","active":true},
  {"name":"刘瑞","phone":"16601182130","city":"北京","department":"运营","active":true},
  {"name":"李海艳","phone":"13520451502","city":"北京","department":"运营","active":true},
  {"name":"王凤娇","phone":"13006599509","city":"北京","department":"运营","active":true},
  {"name":"刘嘉","phone":"18641059784","city":"北京","department":"运营","active":true},
  {"name":"莫倩","phone":"15536867117","city":"北京","department":"运营","active":true},
  {"name":"刘玉","phone":"15210420407","city":"北京","department":"运营","active":true},
  {"name":"付罗杰","phone":"18311382638","city":"北京","department":"运营","active":true},
  {"name":"王灿","phone":"18438447242","city":"北京","department":"运营","active":true},
  {"name":"彭跃慧","phone":"18701376861","city":"北京","department":"运营","active":true}
];

async function importEmployees() {
  const response = await fetch('http://localhost:3000/api/auth/employees/import', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ employees })
  });
  const result = await response.json();
  console.log(`导入完成: ${result.imported}/${result.total} 新员工`);
}

importEmployees().catch(console.error);
